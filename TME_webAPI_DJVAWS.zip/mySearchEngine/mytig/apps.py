from django.apps import AppConfig


class MytigConfig(AppConfig):
    name = 'mytig'
